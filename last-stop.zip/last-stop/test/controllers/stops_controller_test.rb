require 'test_helper'

class StopsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
